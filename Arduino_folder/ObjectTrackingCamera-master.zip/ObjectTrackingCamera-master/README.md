# Object Tracking Camera (Arduino part)

This sw control servo motors to make the android camera track the target object.
[![Simple Object Tracking Camera DIY
](http://img.youtube.com/vi/J4Bvrvfg920/0.jpg)](https://www.youtube.com/watch?v=J4Bvrvfg920 "Simple Object Tracking Camera DIY")

### Dependencies:
1.Download and install library: https://github.com/nabontra/ServoTimer2 via Sketch/Include library/Add .Zip library ... <br/>
2.Install AltSoftSerial via Libray Manager <br/>

### License

BSD 2-Clause "Simplified" License

